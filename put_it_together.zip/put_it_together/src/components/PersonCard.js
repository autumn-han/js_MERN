import React, { useState } from 'react';

const PersonCard = (props) => {
    const [years, setYears] = useState(props.age);
    const incrAge = () => {
        setYears(
            years + 1
        );
    }
    return (
        <div>
            <h1>{props.lname}, {props.fname}</h1>
            <p>Age: {years}</p>
            <p>Hair Color: {props.hair}</p>
            <button onClick={incrAge}>Birthday Button for {props.fname} {props.lname}</button>
        </div>
    );
}

export default PersonCard;