import './App.css';
import PersonCard from './components/PersonCard';

function App() {
  return (
    <div>
      <div>
        <PersonCard lname={"Doe"} fname={"Jane"} age={45} hair={"black"} />
      </div>
      <div>
        <PersonCard lname={"Smith"} fname={"John"} age={88} hair={"brown"} />
      </div>
      <div>
        <PersonCard lname={"Fillmore"} fname={"Millard"} age={50} hair={"brown"} />
      </div>
      <div>
        <PersonCard lname={"Smith"} fname={"Maria"} age={62} hair={"brown"} />
      </div>
    </div>
  )
}

export default App;
